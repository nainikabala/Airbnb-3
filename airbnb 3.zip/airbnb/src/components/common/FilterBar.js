import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import HomeIcon from '@mui/icons-material/Home';
import CabinIcon from '@mui/icons-material/Cabin';

export default function FilterBar() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" color="secondary">
        <Toolbar>
          <Box sx={{display:'flex', justifyContent:'space-between'}} >
          {
            [1,2,3,4,5,6,7].map(n=>(n % 2 === 0 ? <HomeIcon /> : <CabinIcon />))
          }
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
