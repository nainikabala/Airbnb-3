import * as React from 'react';
import Card from '@mui/material/Card';

import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import StarIcon from '@mui/icons-material/Star';
import Favorite from '@mui/icons-material/Favorite';


export default function GCard({info}) {
  
  const itemInfo = (itemData) => {
    console.log("Item info ::: ", itemData);
  }


  return (
    <Card sx={{ maxWidth: 345 }} elevation={0} onClick={()=>itemInfo(info)}>
      <Button   style={{top:50,zIndex:3,left:'75%' }}>

      <Favorite  color='white'/>
      </Button>
      <CardMedia  
    
        component="img"
        height="240"
        width={150}
        sx={{borderRadius:'30px',position:'relative'}}
        image={info.images.picture_url}
        alt="green iguana"
      />
      <CardContent >
        <Box display={"flex"} flexDirection='row' justifyContent={'space-between'} alignItems='flex-start' >
          <Typography gutterBottom variant="h9" component="div"  >
            <Box sx={{ fontWeight: 'bold', m: 1 }}>{info.name}</Box>
          </Typography>
          <Box display={"flex"} flexDirection='row' alignItems={'center'} justifyItems='flex-start' >
            <Typography component="div"  variant="h14">
              <Box sx={{ fontWeight: 'light', m: 1 }}>new</Box>
            </Typography>
            <StarIcon  />
          </Box>
        </Box>
          <Typography variant="div">
          <Box sx={{ fontWeight: 'light', m: 1 }}>{info.summary.substring(0,150)}....</Box>
          </Typography>
          <Box display={"flex"} flexDirection='row'   alignItems={'center'}   justifyContent='flex-start' >
            <Typography variant="subtitle2" color="text.secondary">
                <Box sx={{ fontWeight: 'bold', m: 1 }}  display={"flex"} flexDirection='row' alignItems={'center'}>
                ${info.price['$numberDecimal']} night
                </Box> 
            </Typography>
         
          </Box>
      </CardContent>
      {/* <CardActions>
        <Button size="small">Share</Button>
        <Button size="small">Learn More</Button>
      </CardActions> */}
    </Card>
  );
}
