import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';

import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';
import IconButton from '@mui/material/IconButton';
import LanguageIcon from '@mui/icons-material/Language';
import DehazeIcon from '@mui/icons-material/Dehaze';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import TextField from '@mui/material/TextField';
import SearchIcon from '@mui/icons-material/Search';

import { InputAdornment } from '@mui/material';

export default function AppHeader() {
  return (
    <Box>
      <AppBar position="fixed" sx={{ bgcolor: "white"}}>
        {/* <Toolbar> */}
        <Box sx={{display:'flex', justifyContent:'space-around'}}>
         <Button>
              <Box
                component="img"
                sx={{
                  height: 75,
                  width: 130,
                  maxHeight: { xs: 233, md: 167 },
                  maxWidth: { xs: 350, md: 250 },
                  objectFit:'contain',
                }}
                alt="The house from the offer."
                src="/logo-airbnb.png"
              />
         </Button>
           
          <Box sx={{marginTop:'28px'}}>
            <TextField
            style={{width:500,borderRadius:40,height:70}}
              label='AnyWhere |  Any week | Add guest'
              InputProps={{
                endAdornment: (
                  <InputAdornment>
                    <IconButton>
                      <SearchIcon />
                      
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />
          </Box>
              <Box sx={{marginTop:'28px',display:'flex', justifyContent:'space-between'}}>
                <Box sx={{marginTop:'5px'}}>
                  <Button color="inherit" sx={{ color:'black' }}>Become a Host</Button>
                </Box>
                <Box sx={{color:'black',marginTop:'10px' }}>
                  <LanguageIcon/>
                </Box>
                <Box sx={{marginLeft:'20px' }}>
                  <Paper elevation={10} sx={{border:'5px',width:'80px',  borderColor:'red', borderRadius:'30px'}} >
                    <Box sx={{display:'flex',padding:'10px',justifyContent:'space-between'}}>
                      <DehazeIcon/>
                      <AccountCircleIcon/>
                      </Box>
                  </Paper>

                </Box>
              </Box>
          </Box>
         
        {/* </Toolbar> */}
      </AppBar>
    </Box>
  );
}
