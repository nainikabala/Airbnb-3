import * as React from 'react';
import { useEffect,useState } from 'react';
import Box from '@mui/material/Box';
import appData from '../../data.json';
import GCard from '../common/GCard';
import Grid from '@mui/material/Grid';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import FilterCarousel from '../common/FilterCarousel';
import KayakingTwoToneIcon from '@mui/icons-material/KayakingTwoTone';
import BeachAccessIcon from '@mui/icons-material/BeachAccess';
import { Image } from '@mui/icons-material';
import PoolTwoToneIcon from '@mui/icons-material/PoolTwoTone';
import HouseboatTwoToneIcon from '@mui/icons-material/HouseboatTwoTone';
import HolidayVillageTwoToneIcon from '@mui/icons-material/HolidayVillageTwoTone';
import { IconButton, Tooltip, Typography } from '@mui/material';
import CottageTwoToneIcon from '@mui/icons-material/CottageTwoTone';
import VillaTwoToneIcon from '@mui/icons-material/VillaTwoTone';
import TuneTwoToneIcon from '@mui/icons-material/TuneTwoTone';
export default function DestinationsView() {
  const [priceFilter, setPriceFilter] = React.useState('');
  const [items, setItems] = React.useState([]);
  const [filterFlag , setFilterFlag] = useState(false);
  const [propertySort, setPropertySort] = useState('');
  const [propertyFilter, setPropertyFilter] = useState('');


  

  useEffect(()=>{
    console.log('from useEffect ', appData);
    setItems(appData.data);
  },[filterFlag])



const   handlePropertyFilter = (proptype)=>{
  if(proptype)
{    setPropertyFilter(proptype)
    let newData = appData.data.filter(f=>{return f.name === proptype})
    console.log('handlePropertyFilter',proptype,newData)
    setItems(newData)
  }else {
    setItems(appData.data);
  }

  }
  const propertyChange = (property) => {
    console.log('Property clicked ::: ', property);
    setPropertySort(property);
  } 
  const handleChange = (event) => {
    setPropertySort('');
    let priceFill = event.target.value;
    console.log('filter val',priceFill);
    setPriceFilter(priceFill);
    let newArr;
    if(priceFill==='acs'){
       newArr = items.sort(function (a, b) {
        return a.price['$numberDecimal'] - b.price['$numberDecimal'];
      });
    }else{
      newArr = items.sort(function (a, b) {
        return b.price['$numberDecimal'] - a.price['$numberDecimal'];
      });
    }
    setItems(newArr);
    setFilterFlag(!filterFlag);

  }

  const handleIconColor = ()=>{
    
  }
    return (
      <Box sx={{display:'flex', flexDirection:'column', marginY:'10%', justifyContent:'space-around',marginX:'10%'}}>
        <Box display={'flex'} justifyContent='center' alignItems={'center'} margin={'2%'}> 

      <Box display={'flex'} justifyContent='space-between' alignItems={'center'} width ='75%'>
      <Tooltip title="Island Resorts">
  <IconButton onClick={()=>{handlePropertyFilter('Island Resorts')}}>
  <KayakingTwoToneIcon fontSize='large' />
  
  </IconButton> 
</Tooltip>
<Tooltip title="Villa hotel and Resorts">
  <IconButton  onClick={()=>{handlePropertyFilter('Villa hotel and Resorts')}}>
  <PoolTwoToneIcon color={'green'} fontSize='large' />
  
  </IconButton>
</Tooltip>
<Tooltip title="Presidential Suite">
  <IconButton  onClick={()=>{handlePropertyFilter('Presidential Suite')}} sx={{display:'flex',flexDirection:'column',justifyContent:'center',alignItems:'center'}}>
  <HouseboatTwoToneIcon fontSize='large' />

  </IconButton>
</Tooltip>
<Tooltip title="Suite Rooms">
  <IconButton  onClick={()=>{handlePropertyFilter("Suite Rooms")}}>
  <HolidayVillageTwoToneIcon  fontSize='large'/>
  
  </IconButton>
</Tooltip>
<Tooltip title="Studio Room">
  <IconButton  onClick={()=>{handlePropertyFilter("Studio Room")}}>
  <CottageTwoToneIcon  fontSize='large'/>
  
  </IconButton>
</Tooltip>
<Tooltip title="Studio Apartment">
  <IconButton  onClick={()=>{handlePropertyFilter("Studio Apartment")}}>
  <VillaTwoToneIcon  fontSize='large'/>
  
  </IconButton>
</Tooltip>
<IconButton  onClick={()=>{handlePropertyFilter("")}}  sx={{display:'flex',justifyContent:'center',alignItems:'center'}}>
<TuneTwoToneIcon  fontSize='large'/>
<Typography>Clear Filters</Typography>
  </IconButton>

      </Box>
        </Box>
      <Box>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Price Filter</InputLabel>
          <Select
          style={{width:'100%'}}
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={priceFilter}
            label="Price Filter"
            onChange={handleChange}
          >
            <MenuItem value={'acs'}>Price ASC</MenuItem>
            <MenuItem value={'desc'}>Price DSC</MenuItem>
          </Select>
        </FormControl>
  
      </Box>
      <Box sx={{margin:'25px',}}>
          <Grid container spacing={3}>   
            {
              propertySort === "" ? ( items && items.map(dest=>
                <Grid item md={3} spacing={3}>
                    <GCard info={dest}/>
                </Grid>
                ) ) : items.map(dest => 
                  

                  {
                    if(dest.property_type===propertySort){
                        return (
                          <Grid item md={3} spacing={3}>
                            <GCard info={dest}/>
                          </Grid>
                        )
                    }
                  }
                  )  
            }
            </Grid>
          </Box>
          {/* <GCardNew/> */}
        </Box>
    );
  }
  