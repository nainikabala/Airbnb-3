import './App.css';
import AppHeader from './components/app/AppHeader';

import DestinationsView from './components/views/DestinationsView';

function App() {
  return (
    <div>
        <AppHeader/>
        {/* <AppHeaderNew /> */}
        {/* <FilterBar /> */}
        {/* <FilterCarousel/> */}
        <DestinationsView/>
    </div>
  );
}
export default App;
